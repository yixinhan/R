#' This is some descriptio of this function.
#' @title simple function
#' 
#' @description today,I create my first function,a very usrful function.
#' 
#' @details you can use this function to caculate x+1,then return the value of x+1.
#' 
#' @param x x is a number
#'
#' @return a dataframe
#' @export
#' @examples x=1;f(x)




f<-function(x){return(x+1)}